<!DOCTYPE html>
<html lang="en">
<head>
        <!-- Required meta tags-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="au theme template">
        <meta name="author" content="Hau Nguyen">
        <meta name="keywords" content="au theme template">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=B612&display=swap" rel="stylesheet">
        <!-- Title Page-->
        <title>Dashboard 3</title>

        <!-- Fontfaces CSS-->
        <link href="css/font-face.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
        <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

        <!-- Bootstrap CSS-->
        <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

        <!-- Vendor CSS-->
        <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
        <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
        <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
        <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
        <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
        <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
        <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

        <!-- Main CSS-->
        <link href="css/theme.css" rel="stylesheet" media="all">
        <script type="text/javascript" src="js/linegraphtotal.js"></script>
    </head>
<body class="animsition">
        <div class="page-wrapper">
             <!-- HEADER DESKTOP-->
            <header class="header-desktop3 d-none d-lg-block">
                <div class="section__content section__content--p35" style="background-color:#005EB8;">
                    <div class="header3-wrap">
                        <div class="header__logo">
                            <a href="index.php">
                                <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                            </a>
                        </div>
                        <a  href="version.php"><div style="height:45px;width:250px;background-color:white;margin-top:25px;border-radius: 5px;border: 2px solid rgba(0, 94, 184, 0.8)"><h4 style="display:flex;justify-content: center;align-items: center;margin-top:10px;font-family:Roboto;">HelpDesk V0.2.1</h4></div></a>
                        <div class="header__tool">
                            <div class="account-wrap">
                                <div class="account-item account-item--style2 clearfix js-item-menu">
                                    <div class="image">
                                        <img src="images/icon/perfil.webp" alt="User icon" />
                                    </div>
                                    <div class="content">
                                        <a class="js-acc-btn" href="#">New User</a>
                                    </div>
                                    <div class="account-dropdown js-dropdown">
                                        <div class="info clearfix">
                                            <div class="image">
                                                <a href="#">
                                                    <img src="images/icon/perfil.webp" alt="John Doe" />
                                                </a>
                                            </div>
                                            <div class="content">
                                                <h5 class="name">
                                                    <a href="#">new user</a>
                                                </h5>
                                                <span class="email">newuser@example.com</span>
                                            </div>
                                        </div>
                                        <div class="account-dropdown__footer">
                                            <a href="logout.php">
                                                <i class="zmdi zmdi-power"></i>Logout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->
            <!-- HEADER MOBILE-->
            <header class="header-mobile header-mobile-2 d-block d-lg-none">
                <div class="header-mobile__bar">
                    <div class="container-fluid">
                        <div class="header-mobile-inner">
                            <a class="logo" href="index.html">
                                <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                            </a>
                            <button class="hamburger hamburger--slider" type="button">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            <div class="sub-header-mobile-2 d-block d-lg-none">
                <div class="header__tool">
                    <div class="account-wrap">
                        <div class="account-item account-item--style2 clearfix js-item-menu">
                            <div class="image">
                                <img src="images/icon/perfil.webp" alt="John Doe" />
                            </div>
                            <div class="content">
                                <a class="js-acc-btn" href="#">New User</a>
                            </div>
                            <div class="account-dropdown js-dropdown">
                                <div class="info clearfix">
                                    <div class="image">
                                        <a href="#">
                                            <img src="images/icon/perfil.webp" alt="John Doe" />
                                        </a>
                                    </div>
                                    <div class="content">
                                        <h5 class="name">
                                            <a href="#">new user</a>
                                        </h5>
                                        <span class="email">newuser@example.com</span>
                                    </div>
                                </div>
                                <div class="account-dropdown__footer">
                                    <a href="logout.php">
                                        <i class="zmdi zmdi-power"></i>Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <b><a href="index.php"class="text-muted" style="padding: 7px 0 0 80px">Index</a></b><a class="text-muted">&nbsp;>>&nbsp; </a><b><a class="text-muted" href="totalcalls.php">Total Calls</a></b>
            <br>
            <!-- PAGE CONTENT - Si no queremos ver la linea gris solo hay que bajar el salto a este div-->
            <div class="page-content--bgf7">
                <!-- WELCOME-->
                <section class="welcome p-t-10">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h1 class="title-4">Detailed View
                                    <span>Total Calls</span>
                                </h1>
                                <hr class="line-seprate">
                            </div>
                        </div>
                    </div>
                </section>
                <script>
    function rotateImage() {
        var img = document.getElementById('myimage');
        img.style.transform = 'rotate(180deg) ';
    }
</script>
                <!-- END WELCOME-->  
                <section class="statistic-chart">
                    <div class="container">
                    <div class="card" style="background-color: rgba(232,237,238,0.75)">
                        <div class="card-header"  style="background-color: rgba(0,114,204,1);height: 35px;height: 65px;"data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                                <h3 style="color: white;padding: 10px 0 10px 0;"class="title-5 m-b-35" data-toggle="collapse" data-parent="#accordion" href="#collapse1">statistics 	&#128200;</h3>
                            </div>
                        
                        <div id="collapse1" class="panel-collapse collapse in">
                        <div class="card-body">
                            <div class="col-md-2 col-lg-2"></div>
                            <div class="col-md-12 col-lg-12">
                                <!-- CHART-->
                                <div class="au-card m-b-30">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40" style="text-decoration: underline;">Calls logged per Month</h3>
                                        <canvas id="mycanvas"></canvas>
                                    </div>
                                </div>
                                </div>
                                <!-- END CHART-->
                            </div>
                        </div>
                        </div>
                    </div>
                </section>              
                <!-- DATA TABLE-->
                <section class="p-t-20">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12" style="border-radius: 5px;">
                            <div class="card" style="background-color: rgba(232,237,238,0.75)">
                            <div class="card-header"  style="background-color: rgba(0,114,204,1);height: 35px;height: 65px;"data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                                <h3 class="title-5 m-b-35" style="color: white;padding: 10px 0 10px 0;">data table</h3>
                                </div>
                                <div id="collapse2" class="panel-collapse collapse show">
                                <div class="card-body">
                                <form action="#" method="post">
                                <div class="table-data__tool">
                                    <div class="table-data__tool-left">
                                        <div class="rs-select2--light rs-select2--md">
                                            <select class="js-select2" name="FilterStatus">
                                                <option selected="selected">Status</option>
                                                <?php
                                                require("db.php");
                                                $query = "Select DISTINCT status from tblsmtdata;";
                                                $result = mysqli_query($con,$query) or die(mysqli_error());
                                                while($row = mysqli_fetch_assoc($result)){
                                                foreach($row as $field => $value){
                                                    if($value==$_POST['FilterStatus']){
                                                        echo "<option selected value=\"".$value."\">".$value."</option>"; 
                                                    }
                                                    else{
                                                    echo "<option value=\"".$value."\">".$value."</option>"; 
                                                    }
                                                }
                                            }   
                                                ?>
                                            </select>
                                            <div class="dropDownSelect2"></div>
                                        </div>
                                        <div class="rs-select2--light rs-select2--md">
                                            <select class="js-select2" name="FilterDate">
                                                <option selected="selected">Filter Date</option>
                                                <option value="7">Last week</option>
                                                <option value="30">Last month</option>
                                                <option value="365">Last year</option>
                                                <option value="366">All (Default)</option>
                                            </select>
                                            <div class="dropDownSelect2"></div>
                                        </div>
                                            <div class="rs-select2--light rs-select2--md">
                                            <select class="js-select2" name="FilterTeam">
                                                <option selected="selected">Team</option>
                                                <?php
                                                require("db.php");
                                                $query = "Select DISTINCT responsible_team from tblsmtdata;";
                                                $result = mysqli_query($con,$query) or die(mysqli_error());
                                                while($row = mysqli_fetch_assoc($result)){
                                                foreach($row as $field => $value){
                                                    if($value==$_POST['FilterTeam']){
                                                        echo "<option selected value=\"".$value."\">".$value."</option>"; 
                                                    }
                                                    else{
                                                    echo "<option value=\"".$value."\">".$value."</option>"; 
                                                    }
                                                }
                                            }   
                                                ?>
                                            </select>
                                            <div class="dropDownSelect2"></div>
                                        </div>
                                    </div>
                                    <input type="submit" name="SubmitButton" value="Filter" class="btn btn-success">
                                </div>
                                <!-- Checkboxfd
                                <div class="table-data__tool">
                                    <div class="table-data__tool-left">
                                        <div class="rs-select2--light rs-select2--md">
                                            <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="materialChecked2" checked>
                                            <label class="form-check-label" for="materialChecked2">Filter Date</label>
                                            </div>
                                            <div class="dropDownSelect2"></div>
                                        </div>
                                        </div>
                                        </div>-->
                                <?php include('insertable.php'); ?>
                            </form>
                            </div>
                            <nav aria-label="...">
                                <ul class="pagination">
                                    <li class="page-item"><a href="?pageno=1" class="page-link">First</a></li>
                                    <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                                        <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>" class="page-link">Prev</a>
                                    </li>
                                    <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                                        <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>" class="page-link">Next</a>
                                    </li>
                                    <li class="page-item"><a href="?pageno=<?php echo $total_pages; ?>" class="page-link">Last</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    </div>
                                        </div>
                                        </div>
                                        <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>                                      
                </section>
                </div>
        </div>
        <!-- Jquery JS-->
        <script src="vendor/jquery-3.2.1.min.js"></script>
        <!-- Bootstrap JS-->
        <script src="vendor/bootstrap-4.1/popper.min.js"></script>
        <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
        <!-- Vendor JS       -->
        <script src="vendor/slick/slick.min.js">
        </script>
        <script src="vendor/wow/wow.min.js"></script>
        <script src="vendor/animsition/animsition.min.js"></script>
        <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
        </script>
        <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
        <script src="vendor/counter-up/jquery.counterup.min.js">
        </script>
        <script src="vendor/circle-progress/circle-progress.min.js"></script>
        <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
        <script src="vendor/chartjs/Chart.bundle.min.js"></script>
        <script src="vendor/select2/select2.min.js">
        </script>

        <!-- Main JS-->
        <script src="js/main.js"></script>
        </body>
</html>