<?php
require('db.php');
$query = "SELECT COUNT(id) FROM tblsmtdata;";
$result = mysqli_query($con,$query);
$row = mysqli_fetch_assoc($result);

?>