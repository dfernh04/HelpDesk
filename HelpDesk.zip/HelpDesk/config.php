<!DOCTYPE html>
<html lang="en">
<head>
        <!-- Required meta tags-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="au theme template">
        <meta name="author" content="Hau Nguyen">
        <meta name="keywords" content="au theme template">

        <!-- Title Page-->
        <title>Dashboard 3</title>
        <!-- Fontfaces CSS-->
        <link href="css/font-face.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
        <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
        <link href="https://fonts.googleapis.com/css?family=B612&display=swap" rel="stylesheet">
        <!-- Bootstrap CSS-->
        <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

        <!-- Vendor CSS-->
        <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
        <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
        <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
        <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
        <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
        <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
        <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

        <!-- Main CSS-->
        <link href="css/theme.css" rel="stylesheet" media="all">

    </head>
<body class="animsition">
        <div class="page-wrapper">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop3 d-none d-lg-block">
                <div class="section__content section__content--p35" style="background-color:#005EB8;">
                    <div class="header3-wrap">
                        <div class="header__logo">
                            <a href="index.php">
                                <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                            </a>
                        </div>
                        <a  href="version.php"><div style="height:45px;width:250px;background-color:white;margin-top:25px;border-radius: 5px;border: 2px solid rgba(0, 94, 184, 0.8)"><h4 style="display:flex;justify-content: center;align-items: center;margin-top:10px;font-family:Roboto;">HelpDesk V0.2.1</h4></div></a>
                        <div class="header__tool">
                            <div class="account-wrap">
                                <div class="account-item account-item--style2 clearfix js-item-menu">
                                    <div class="image">
                                        <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                    </div>
                                    <div class="content">
                                        <a class="js-acc-btn" href="#">john doe</a>
                                    </div>
                                    <div class="account-dropdown js-dropdown">
                                        <div class="info clearfix">
                                            <div class="image">
                                                <a href="#">
                                                    <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                                </a>
                                            </div>
                                            <div class="content">
                                                <h5 class="name">
                                                    <a href="#">john doe</a>
                                                </h5>
                                                <span class="email">johndoe@example.com</span>
                                            </div>
                                        </div>
                                        <div class="account-dropdown__footer">
                                            <a href="logout.php">
                                                <i class="zmdi zmdi-power"></i>Logout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->
            <!-- HEADER MOBILE-->
            <header class="header-mobile header-mobile-2 d-block d-lg-none">
                <div class="header-mobile__bar">
                    <div class="container-fluid">
                        <div class="header-mobile-inner">
                            <a class="logo" href="index.html">
                                <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                            </a>
                            <button class="hamburger hamburger--slider" type="button">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            <div class="sub-header-mobile-2 d-block d-lg-none">
                <div class="header__tool">
                    <div class="account-wrap">
                        <div class="account-item account-item--style2 clearfix js-item-menu">
                            <div class="image">
                                <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                            </div>
                            <div class="content">
                                <a class="js-acc-btn" href="#">john doe</a>
                            </div>
                            <div class="account-dropdown js-dropdown">
                                <div class="info clearfix">
                                    <div class="image">
                                        <a href="#">
                                            <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                        </a>
                                    </div>
                                    <div class="content">
                                        <h5 class="name">
                                            <a href="#">john doe</a>
                                        </h5>
                                        <span class="email">johndoe@example.com</span>
                                    </div>
                                </div> 
                                <div class="account-dropdown__footer">
                                    <a href="logout.php">
                                        <i class="zmdi zmdi-power"></i>Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <b><a href="index.php"class="text-muted" style="padding: 7px 0 0 80px">Index</a></b><a class="text-muted">&nbsp;>>&nbsp; </a><b><a class="text-muted" href="config.php">Configuration</a></b>
            <br>
            <!-- PAGE CONTENT-->
            <div class="page-content--bgf7">
                <!-- WELCOME-->
                <section class="welcome p-t-10">
                    <div class="container">
                    <h1 class="title-4">Configuration
                                    <span>Window:</span>
                                    <hr class="line-seprate">
                                </h1>
                        <div class="row">
                          <div class="col-lg-2"></div>
                            <div class="col-lg-8" style="background-color:rgba(118,134,146,0.1);margin-top: 20px;border: 2px solid rgba(118,134,146,1);min-height: 700px;border-radius: 2px;">
                            <h3 class="title-5 m-b-35" style="padding: 25px 0 0 25px;">Global Configuration Options:</h3>    
                            <div class="row">
                                <div class="col-lg-1"></div>
                                <div class="col-lg-10" style="text-align: left;background-color: rgba(66,85,99,0.1);border-radius: 5px; border:1px solid rgba(66,85,99,1)">
                              <div class="row">
                              <div class="col-lg-2"></div>
                              <div class="col-lg-8">
                                <div class="form-group">
    <label for="exampleFormControlSelect1" style="color:black;margin-top: 15px;">Number of Rows per page:</label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>5</option>
      <option>15</option>
      <option>25</option>
      <option>50</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1" style="color:black;margin-top: 15px;">Main Chart type: </label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>Doughnut Chart</option>
      <option>Polar Chart</option>
      <option>Pie Chart</option>
    </select>
  </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1" style="color: black;">Show closed tickets</label>
  </div>
                              </div>
                              </div>
                              </div>
                              </div>
                                <h3 class="title-5 m-b-35" style="padding: 25px 0 0 25px;">Appareance Configuration Options:</h3>    
                            <div class="row">
                                <div class="col-lg-1"></div>
                                <div class="col-lg-10" style="height: 200px; text-align: center;background-color: rgba(66,85,99,0.1);border-radius: 5px; border:1px solid rgba(66,85,99,1)"></div>
                                </div>
                                <h3 class="title-5 m-b-35" style="padding: 25px 0 0 25px;">DataBase Variables configuration:</h3>    
                            <div class="row" style="padding: 0 0 50px 0;">
                                <div class="col-lg-1"></div>
                                <div class="col-lg-10" style="text-align: left;background-color: rgba(66,85,99,0.1);border-radius: 5px; border:1px solid rgba(66,85,99,1)">
                                <div class="row">
                              <div class="col-lg-2"></div>
                              <div class="col-lg-8">
                                <div class="form-group">
    <label for="exampleFormControlInput1" style="color: black;">Server Address:</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="localhost">
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1"style="color: black;">Username:</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="admin">
  </div>
  <div class="form-group"style="color: black;">
    <label for="exampleFormControlInput1">Password:</label>
    <input type="password" class="form-control" id="exampleFormControlInput1" placeholder="pazzword">
  </div>
  <div class="form-group"style="color: black;">
    <label for="exampleFormControlInput1">Database name:</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
</div>
                                </div>
                              </div>
                                </div>
                                <div class="wrapper" style="text-align: center;padding: 5px 0 15px 0;"><input class="btn btn-primary" type="submit" value="Submit" style="width: 500px;"></div>
                            </div>
                            <div class="col-lg-2">
                            </div>
                        </div>
                    </div>
                </section>
                <br>     <br>     <br>
                <!-- END WELCOME-->       
                <!-- DATA TABLE-->
                <!-- Siguiente -->
            </div>
        </div>
        <!-- Jquery JS-->
        <script src="vendor/jquery-3.2.1.min.js"></script>
        <!-- Bootstrap JS-->
        <script src="vendor/bootstrap-4.1/popper.min.js"></script>
        <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
        <!-- Vendor JS       -->
        <script src="vendor/slick/slick.min.js">
        </script>
        <script src="vendor/wow/wow.min.js"></script>
        <script src="vendor/animsition/animsition.min.js"></script>
        <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
        </script>
        <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
        <script src="vendor/counter-up/jquery.counterup.min.js">
        </script>
        <script src="vendor/circle-progress/circle-progress.min.js"></script>
        <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
        <script src="vendor/chartjs/Chart.bundle.min.js"></script>
        <script src="vendor/select2/select2.min.js">
        </script>

        <!-- Main JS-->
        <script src="js/main.js"></script>
        </body>
</html>