$(document).ready(function(){
    $.ajax({
        url: "datachart.php",
        type: "GET",
        success: function(data){
            console.log(data);

            var team = [];
            var suma = [];

            for(var i in data){
                team.push(data[i].responsible_team);
                suma.push(data[i].sum);
            }
            var chardata = {
                datasets:[{
                    data: suma,
                    backgroundColor: [
                        "#003f5c",
"#374c80",
"#7a5195",
"#bc5090",
"#ef5675",
"#ff764a",
"#ffa600"
                    ],
                    hoverBackgroundColor: [
                        "#003f5c",
"#374c80",
"#7a5195",
"#bc5090",
"#ef5675",
"#ff764a",
"#ffa600"
                    ]
                  }],
                  labels: team
            };

        var ctx = $("#mycanvas");

        var LineGraph = new Chart(ctx, {
            type:'pie',
            data: chardata,
            options: {
                legend: {
                    position: 'left',
                        labels: {
                            fontFamily: 'Roboto',
                            fontSize: 16,
                        }

                    },
                    responsive: true
            }
        });
        },
        error : function(data){
            console.log("ERROR FATAL",data);
        }
    });
});