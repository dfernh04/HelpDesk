$(document).ready(function(){
    $.ajax({
        url: "datasinglebarchart.php",
        type: "GET",
        success: function(data){
            console.log(data);

            var team = [];
            var suma = [];

            for(var i in data){
                team.push(data[i].team);
                suma.push(data[i].total);
            }
            var chardata = {
                datasets:[{
                    data: suma,
                    label: "Calls closed",
                    borderColor: "rgba(0,0,0,.09)",
                    borderWidth: "1",
                    backgroundColor: [
                        "#003f5c",
"#374c80",
"#7a5195",
"#bc5090",
"#ef5675",
"#ff764a",
"#ffa600"
                    ]
                  }],
                  labels: team
            };

        var ctx = $("#mycanvas");

        var LineGraph = new Chart(ctx, {
            type:'bar',
            data: chardata,
            options: {
                legend: {
                    position: 'left',
                        labels: {
                            fontFamily: 'B612',
                            fontSize: 16,
                        }

                    },
                    responsive: true,
                    tooltips: {
                        mode: 'index',
                        intersect: false
                      },
                      hover: {
                        mode: 'nearest',
                        intersect: true
                      },
                      scales: {
                        xAxes: [{
                          ticks: {
                            fontFamily: "Poppins"
            
                          }
                        }],
                        yAxes: [{
                          ticks: {
                            beginAtZero: true,
                            fontFamily: "Poppins"
                          }
                        }]
                      }
            }
        });
        },
        error : function(data){
            console.log("ERROR FATAL",data);
        }
    });
});