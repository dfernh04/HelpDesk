$(document).ready(function(){
    $.ajax({
        url: "datateamchart.php",
        type: "GET",
        success: function(data){
            console.log(data);

            var team = [];
            var sumateam = [];
            var individual = []
            var sumaindividual = []
            var fecha = []

            for(var i in data){
                if(data[i].disp=="team"){
                sumateam.push(data[i].contador);
                fecha.push((data[i].mes).concat(" "+data[i].ano))
                }
                else if(data[i].disp=="individual"){
                sumaindividual.push(data[i].contador);
                fecha.push((data[i].mes).concat(" "+data[i].ano))
                }
            }
            var chardata = {
                datasets:[{
                    data: sumateam,
                    label: "Team closed",
                    borderColor: "rgba(0,0,0,.99)",
                    borderWidth: "1",
                    backgroundColor: "rgba(0,164,153, 0.5)"
                  },{
                    data: sumaindividual,
                    label: "Personal closed",
                    borderColor: "rgba(0,0,0,.99)",
                    borderWidth: "1",
                    backgroundColor: "rgba(0,150,57, 0.5)"
                  }],
                  labels: fecha
            };

        var ctx = $("#mycanvas");

        var LineGraph = new Chart(ctx, {
            type:'line',
            data: chardata,
            options: {
                legend: {
                    position: 'left',
                        labels: {
                            fontFamily: 'Roboto',
                            fontSize: 16,
                        }

                    },
                    responsive: true,
                    tooltips: {
                        mode: 'index',
                        intersect: false
                      },
                      hover: {
                        mode: 'nearest',
                        intersect: true
                      },
                      scales: {
                        xAxes: [{
                          ticks: {
                            fontFamily: "Roboto"
            
                          }
                        }],
                        yAxes: [{
                          ticks: {
                            beginAtZero: true,
                            fontFamily: "Roboto"
                          }
                        }]
                      }
            }
        });
        },
        error : function(data){
            console.log("ERROR FATAL",data);
        }
    });
});