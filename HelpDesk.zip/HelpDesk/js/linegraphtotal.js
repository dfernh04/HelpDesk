$(document).ready(function(){
    $.ajax({
        url: "datalinechart.php",
        type: "GET",
        success: function(data){
            console.log(data);

            var team = [];
            var suma = [];

            for(var i in data){
                team.push((data[i].month).concat(" "+data[i].year));
                suma.push(data[i].sum);
            }
            var chardata = {
                datasets:[{
                    data: suma,
                    label: "Calls closed",
                    borderColor: "rgba(0,0,0,.99)",
                    borderWidth: "1",
                    backgroundColor: "rgba(11, 156, 49, 0.5)"
                  }],
                  labels: team
            };

        var ctx = $("#mycanvas");

        var LineGraph = new Chart(ctx, {
            type:'line',
            data: chardata,
            options: {
                legend: {
                    position: 'left',
                        labels: {
                            fontFamily: 'Roboto',
                            fontSize: 16,
                        }

                    },
                    responsive: true,
                    tooltips: {
                        mode: 'index',
                        intersect: false
                      },
                      hover: {
                        mode: 'nearest',
                        intersect: true
                      },
                      scales: {
                        xAxes: [{
                          ticks: {
                            fontFamily: "Roboto"
            
                          }
                        }],
                        yAxes: [{
                          ticks: {
                            beginAtZero: true,
                            fontFamily: "Roboto"
                          }
                        }]
                      }
            }
        });
        },
        error : function(data){
            console.log("ERROR FATAL",data);
        }
    });
});