<?php
require('db.php');
//setting header to json
header('Content-Type: application/json');
$responsible = $_COOKIE['responsible_team'];
//database
$query = "SELECT count(id) as contador,MONTHNAME(logged_date) as mes,YEAR(logged_date) as ano,'individual' as disp FROM tblsmtdata where contact_id = '".$_COOKIE['contact_id']."' and status like 'closed' GROUP by mes,ano  UNION SELECT count(id) as contador,MONTHNAME(logged_date) as mes,YEAR(logged_date) as ano,'team' as disp FROM tblsmtdata where responsible_team like '".$responsible."' and status like 'closed' GROUP BY mes,ano ORDER BY ano";
$result =  mysqli_query($con,$query);
$data = array();
while($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}
print json_encode($data);
?>