<!DOCTYPE html>
<html lang="en">
<head>
        <!-- Required meta tags-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="au theme template">
        <meta name="author" content="Hau Nguyen">
        <meta name="keywords" content="au theme template">

        <!-- Title Page-->
        <title>Dashboard 3</title>

        <!-- Fontfaces CSS-->
        <link href="css/font-face.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
        <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
        <link href="https://fonts.googleapis.com/css?family=B612&display=swap" rel="stylesheet">
        <!-- Bootstrap CSS-->
        <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

        <!-- Vendor CSS-->
        <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
        <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
        <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
        <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
        <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
        <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
        <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

        <!-- Main CSS-->
        <link href="css/theme.css" rel="stylesheet" media="all">

    </head>
<body class="animsition">
        <div class="page-wrapper">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop3 d-none d-lg-block">
                <div class="section__content section__content--p35" style="background-color:#005EB8;">
                    <div class="header3-wrap">
                        <div class="header__logo">
                            <a href="index.php">
                                <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                            </a>
                        </div>
                        <a  href="version.php"><div style="height:45px;width:250px;background-color:white;margin-top:25px;border-radius: 5px;border: 2px solid rgba(0, 94, 184, 0.8)"><h4 style="display:flex;justify-content: center;align-items: center;margin-top:10px;font-family:Roboto;">HelpDesk V0.2.1</h4></div></a>
                        <div class="header__tool">
                            <div class="account-wrap">
                                <div class="account-item account-item--style2 clearfix js-item-menu">
                                    <div class="image">
                                        <img src="images/icon/perfil.webp" alt="User icon" />
                                    </div>
                                    <div class="content">
                                        <a class="js-acc-btn" href="#">New User</a>
                                    </div>
                                    <div class="account-dropdown js-dropdown">
                                        <div class="info clearfix">
                                            <div class="image">
                                                <a href="#">
                                                    <img src="images/icon/perfil.webp" alt="John Doe" />
                                                </a>
                                            </div>
                                            <div class="content">
                                                <h5 class="name">
                                                    <a href="#">new user</a>
                                                </h5>
                                                <span class="email">newuser@example.com</span>
                                            </div>
                                        </div>
                                        <div class="account-dropdown__footer">
                                            <a href="logout.php">
                                                <i class="zmdi zmdi-power"></i>Logout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->
            <!-- HEADER MOBILE-->
            <header class="header-mobile header-mobile-2 d-block d-lg-none">
                <div class="header-mobile__bar">
                    <div class="container-fluid">
                        <div class="header-mobile-inner">
                            <a class="logo" href="index.html">
                                <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                            </a>
                            <button class="hamburger hamburger--slider" type="button">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            <div class="sub-header-mobile-2 d-block d-lg-none">
                <div class="header__tool">
                    <div class="account-wrap">
                        <div class="account-item account-item--style2 clearfix js-item-menu">
                            <div class="image">
                                <img src="images/icon/perfil.webp" alt="John Doe" />
                            </div>
                            <div class="content">
                                <a class="js-acc-btn" href="#">New User</a>
                            </div>
                            <div class="account-dropdown js-dropdown">
                                <div class="info clearfix">
                                    <div class="image">
                                        <a href="#">
                                            <img src="images/icon/perfil.webp" alt="John Doe" />
                                        </a>
                                    </div>
                                    <div class="content">
                                        <h5 class="name">
                                            <a href="#">new user</a>
                                        </h5>
                                        <span class="email">newuser@example.com</span>
                                    </div>
                                </div>
                                <div class="account-dropdown__footer">
                                    <a href="logout.php">
                                        <i class="zmdi zmdi-power"></i>Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <b><a href="index.php"class="text-muted" style="padding: 7px 0 0 80px">Index</a></b><a class="text-muted">&nbsp;>>&nbsp; </a><b><a class="text-muted" href="showdetailed.php?val=<?php echo $_GET['val'];?>">Show Detailed</a></b>
            <br>
            <!-- PAGE CONTENT-->
            <div class="page-content--bgf7">
                <!-- WELCOME-->
                <section class="welcome p-t-10">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h1 class="title-4">Details
                                    <span>Issue with ID: <b><?php echo $_GET["val"];?></b></span>
                                </h1>
                                <hr class="line-seprate">
                            </div>
                        </div>
                    </div>
                </section>
                <!-- END WELCOME-->
                <?php
                 require("db.php");
                 $query = "Select contact_id,id,resolution_hours,contact_name,priority,responsible_team,status,caused_by from tblsmtdata WHERE id=".$_GET["val"].";";
                 $result = mysqli_query($con,$query) or die(mysqli_error());
                 $row = mysqli_fetch_assoc($result);
                 if($row['priority']<=5){
                    $color="green";
                }elseif($row['priority']>5 && $row['priority']<7){
                    $color="orange";
                }else{
                    $color="red";
                }
                if($row['status']=="Closed" || $row['status']=="closed" ){
                    $colorstatus ="red";
                }elseif($row['status']=="Close Pend"){
                    $colorstatus ="orange";
                }else{
                    $colorstatus ="green";
                }
                ?>           
                <!-- DATA TABLE-->
                <section class="p-t-20">
                    <div class="container">
                        <div class="row">
                        <div class="table-responsive table-responsive-data2">
                                <table class="table table-data2">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Resolution hours</th>
                                            <th>Contact name</th>
                                            <th>Team</th>
                                            <th>Priority</th>
                                            <th>status</th>
                                            <th>Caused by</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="tr-shadow">
                                            <td><?php echo $row['id'];?></td>
                                            <td>
                                                <span class="block-email"><?php echo $row['resolution_hours'];?></span>
                                            </td>
                                            <td class="desc"><a href="personal.php?val=<?php echo $row['contact_id'];?>"><?php echo $row['contact_name'];?></a></td>
                                            <td><?php echo $row['responsible_team'];?></td>
                                            <td <?php echo 'style=color:'.$color.''?>><?php echo $row['priority'];?></td>
                                            <td>
                                                <span <?php echo 'style=color:'.$colorstatus.''?> class="status--process"><?php echo $row['status'];?></span>
                                            </td>
                                            <td><?php echo $row['caused_by']; ?></td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    </tbody>
                                </table>
                                </div>
                        </div>
                    </div>
                </section>
                <!-- Siguiente -->
                <section class="p-t-30">
                    <div class="container">
                        <div class="row">
                            <h4 class="tittle">Info detail</h4>
                            <hr class="line-seprate">
                        </div>
                    </div>
                    <br>
                    <?php
                 require("db.php");
                 $query = "Select contact_id,id,subject,description,status,resolution_hours,contact_name,locality,contact_email,base,lead_display_name,lead_telephone,altered_date,Rundatetime from tblsmtdata WHERE id=".$_GET["val"].";";
                 $result = mysqli_query($con,$query) or die(mysqli_error());
                 while($row = mysqli_fetch_assoc($result)) {
                     echo '<div class="row">
                     <div class="col-md-2 col-lg-1"></div>
                     <div class="col-md-6 col-lg-10">
                         <div class="au-card m-b-30">
                             <div class="card-header" data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                             <h3 class="title-5 m-b-15">Featured</h3>
                             </div>
                             <div id="collapse1" class="panel-collapse collapse show">     
                             <div class="card-body">
                            <p><a class="card-text"><b>Subject: </b></a><a style="margin-left:125px;">'.$row['subject'].'</a></p>
                            <p><a class="card-text"><b>Description: </b></a><a style="margin-left:95px;">'.$row['description'].'</a></p>
                            <p><a class="card-text"><b>Status: </b></a><a style="margin-left:135px;color:'.$colorstatus.';">'.$row['status'].'</a></p>
                            <p><a class="card-text"><b>Resolution Hours: </b></a><a style="margin-left:55px;">'.$row['resolution_hours'].'</a></p>
                             </div>
                             </div>
                             <br>
                             <div class="card-header" data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                             <h3 class="title-5 m-b-15">Contact</h3>
                             </div>
                             <div id="collapse2" class="panel-collapse collapse show">   
                             <div class="card-body">
                             <p><a class="card-text"><b>Name: </b></a><a href="personal.php?val='.$row['contact_id'].'" style="margin-left:150px;">'.$row['contact_name'].'</a></p>
                             <p><a class="card-text"><b>Local: </b></a><a style="margin-left:150px;">'.$row['locality'].'</a></p>
                             <p><a class="card-text"><b>Email: </b></a><a style="margin-left:150px;">'.$row['contact_email'].'</a></p>
                             <p><a class="card-text"><b>Team: </b></a><a style="margin-left:150px;">'.$row['base'].'</a></p>
                             <p><a class="card-text"><b>Lead name:: </b></a><a style="margin-left:105px;">'.$row['lead_display_name'].'</a></p>
                             <p><a class="card-text"><b>Lead telephone: </b></a><a style="margin-left:75px; color: orange;text-decoration: none;">'.$row['lead_telephone'].'</a></p>
                             </div>
                             </div>
                             <br>
                             <div class="card-header" data-toggle="collapse" data-parent="#accordion" href="#collapse3">
                             <h3 class="title-5 m-b-15">Date features</h3>
                             </div>
                             <div id="collapse3" class="panel-collapse collapse show">   
                             <div class="card-body">
                             <p><a class="card-text"><b>Altered Date: </b></a><a style="margin-left:150px;">'.$row['altered_date'].'</a></p>
                             <p><a class="card-text"><b>Run Date Time: </b></a><a style="margin-left:130px;">'.$row['Rundatetime'].'</a></p>
                             </div>
                             </div>    
                         </div>
                     </div>
                 </div>';
                 }
                 ?>
                  <br>
                                            <br>
                                            <br>
                                            <br>
                </section>
            </div>
        </div>
        <!-- Jquery JS-->
        <script src="vendor/jquery-3.2.1.min.js"></script>
        <!-- Bootstrap JS-->
        <script src="vendor/bootstrap-4.1/popper.min.js"></script>
        <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
        <!-- Vendor JS       -->
        <script src="vendor/slick/slick.min.js">
        </script>
        <script src="vendor/wow/wow.min.js"></script>
        <script src="vendor/animsition/animsition.min.js"></script>
        <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
        </script>
        <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
        <script src="vendor/counter-up/jquery.counterup.min.js">
        </script>
        <script src="vendor/circle-progress/circle-progress.min.js"></script>
        <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
        <script src="vendor/chartjs/Chart.bundle.min.js"></script>
        <script src="vendor/select2/select2.min.js">
        </script>

        <!-- Main JS-->
        <script src="js/main.js"></script>
        </body>
</html>