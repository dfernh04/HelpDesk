<?php
require('db.php');
//setting header to json
header('Content-Type: application/json');

//database
$query = "Select responsible_team, sum(minutes_contributed) as sum FROM tblsmtdata group by responsible_team order by sum desc";
$result =  mysqli_query($con,$query) or die(mysqli_error());
$data = array();
while($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}
print json_encode($data);
?>