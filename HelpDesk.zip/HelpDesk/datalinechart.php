<?php
require('db.php');
//setting header to json
header('Content-Type: application/json');

//database
$query = "SELECT MONTHNAME(LOGGED_DATE) as month, YEAR(logged_date) as year,COUNT(ID) as sum FROM tblsmtdata GROUP BY MONTHNAME(logged_date),YEAR(logged_date) ORDER BY YEAR(logged_date)";
$result =  mysqli_query($con,$query) or die(mysqli_error());
$data = array();
while($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}
print json_encode($data);
?>