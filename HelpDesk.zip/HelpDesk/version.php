<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Dashboard 3</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="https://fonts.googleapis.com/css?family=B612&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper" style="background-color:rgba(0, 0, 0, 0.1)">
        <!-- HEADER DESKTOP-->
        <header class="header-desktop3 d-none d-lg-block">
            <div class="section__content section__content--p35" style="background-color:#005EB8;">
                <div class="header3-wrap">
                    <div class="header__logo">
                        <a href="index.php">
                            <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                        </a>
                    </div>
                    <a href="version.php">
                        <div style="height:45px;width:250px;background-color:white;margin-top:25px;border-radius: 5px;border: 2px solid rgba(0, 94, 184, 0.8)">
                            <h4 style="display:flex;justify-content: center;align-items: center;margin-top:10px;font-family:Roboto;">HelpDesk V0.2.1</h4>
                        </div>
                    </a>
                    <div class="header__tool">
                        <div class="account-wrap">
                            <div class="account-item account-item--style2 clearfix js-item-menu">
                                <div class="image">
                                    <img src="images/icon/perfil.webp" alt="John Doe" />
                                </div>
                                <div class="content">
                                    <a class="js-acc-btn" href="#">New User</a>
                                </div>
                                <div class="account-dropdown js-dropdown">
                                    <div class="info clearfix">
                                        <div class="image">
                                            <a href="#">
                                                <img src="images/icon/perfil.webp" alt="John Doe" />
                                            </a>
                                        </div>
                                        <div class="content">
                                            <h5 class="name">
                                                <a href="#">new user</a>
                                            </h5>
                                            <span class="email">newuser@example.com</span>
                                        </div>
                                    </div>
                                    <div class="account-dropdown__footer">
                                        <a href="logout.php">
                                            <i class="zmdi zmdi-power"></i>Logout</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER DESKTOP-->

        <!-- HEADER MOBILE-->
        <header class="header-mobile header-mobile-2 d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/rsz_nhs-logo.png" alt="Midlands Partnership NHS Foundation Trust" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </header>
        <div class="sub-header-mobile-2 d-block d-lg-none">
            <div class="header__tool">
                <div class="account-wrap">
                    <div class="account-item account-item--style2 clearfix js-item-menu">
                        <div class="image">
                            <img src="images/icon/images/icon/perfil.webp" alt="John Doe" />
                        </div>
                        <div class="content">
                            <a class="js-acc-btn" href="#">New User</a>
                        </div>
                        <div class="account-dropdown js-dropdown">
                            <div class="info clearfix">
                                <div class="image">
                                    <a href="#">
                                        <img src="images/icon/images/icon/perfil.webp" alt="John Doe" />
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="name">
                                        <a href="#">new user</a>
                                    </h5>
                                    <span class="email">newuser@example.com</span>
                                </div>
                            </div>
                            <div class="account-dropdown__body">
                                <div class="account-dropdown__item">
                                    <a href="config.php">
                                        <i class="zmdi zmdi-account"></i>Account</a>
                                </div>
                            </div>
                            <div class="account-dropdown__footer">
                                <a href="logout.php">
                                    <i class="zmdi zmdi-power"></i>Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <b><a href="index.php" class="text-muted" style="padding: 7px 0 0 80px">Index</a></b><a class="text-muted">&nbsp;>>&nbsp; </a><b><a class="text-muted" href="version.php">Version Logger</a></b>
        <br>
        <!-- PAGE CONTENT-->
        <div class="page-content--bgf7">
            <!-- WELCOME-->
            <section class="welcome p-t-10">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="title-4">
                                <span>HelpDesk Version Logger 📊</span>
                            </h1>
                            <hr class="line-seprate">
                        </div>
                    </div>
                </div>
            </section>
            <!-- END WELCOME-->
            <div id="accordion">
            <div class="container">
                <div class="card">
                    <div class="card-header" style="background-color: rgba(0,114,204,1);" id="headingOne">
                        <h5 class="mb-0">
                            <button style="color:white;"class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                Version 0.1
                            </button>
                        </h5>
                    </div>

                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                        <div class="card-body">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="card-title">Project summary is delivered to the developer</h5>
                                <small>10/12/2019</small>
                            </div>
                            <p>At this time, the document with the different requirements and use cases that the project must overcome is handed over to the person who will develop the system, starting from there begins a work of analysis and design, identifying the different objects present and their interactions.</p>
                            <p>A line of work is defined to be followed throughout the development and the technologies to be used:</p><br>
                            <ul class="list">
                                <li style="margin-left:50px;"><a href="https://www.mysql.com/"><img src="images/icon/mysql.png" style="height:30px;margin:auto;"></a><b>&nbsp;&nbsp;&nbsp;MySQL:</b> A relational database management system developed under dual license: General Public License / Commercial License by Oracle Corporation and is considered the most popular open source database in the world, used in the prototype phase to advance in more refined versions of <b>Microsoft SQL Server</b>.</li>
                                <li style="margin-left:50px;"><a href="https://www.php.net/"><img src="images/icon/php.png" style="height:30px;margin:auto;"></a><b>&nbsp;&nbsp;&nbsp;Php:</b>It is a general-purpose programming language of server-side code originally designed for plain text preprocessing in UTF-8. Subsequently it was applied to web development of dynamic content, in this project php is used to automate functions and simplify code in addition to managing communications with the database</li>
                                <li style="margin-left:50px;"><a href="https://www.javascript.com/"><img src="images/icon/html.png" style="height:35px;margin:auto;"></a><b>&nbsp;&nbsp;&nbsp;Html: </b> it refers to the markup language for the elaboration of web pages. It is a standard that serves as a reference for the software that connects to the development of web pages in its different versions, defines a basic structure and a code for defining the content of a web page</li>
                                <li style="margin-left:50px;"><a href="https://www.w3schools.com/html/"><img src="images/icon/js.png" style="height:35px;margin:auto;"></a><b>&nbsp;&nbsp;&nbsp;Javascript: </b>JavaScript is an interpreted programming language, dialect of the ECMAScript standard. It is defined as object-oriented, prototype-based, imperative, weakly typed and dynamic, used in the project to connect the front end part with the back-end information and provide dynamism to the page.</li>
                            </ul>
                            <br>
                            <p>JavaScript libraries are files with instructions to add various functionalities and effects to Internet pages, all modern browsers natively include JavaScript, which allows them to interpret basic functions, these libraries add other resources to manipulate the structure of the pages ( DOM) dynamically and visual style (CSS), as demanded by the modern web, among them the following have been used:</p><br>
                            <ul>
                                <li style="margin-left:50px;"><b>JQuery: </b>JQuery is widely used to make changes dynamically in the DOM (page structures), without having to reload them and add a lot of effects and animations.</li>
                                <li style="margin-left:50px;"><b>Bootstrap: </b>Bootstrap is a free and open source web framework (framework), very popular used to create websites.
                                    It offers HTML templates, CSS style sheets, fonts and a library to add additional functionalities to the pages, for example buttons, menus, navigation bars, panels, image viewers, etc.</li>
                                    <li style="margin-left:50px;"><b>Chart.js: </b>Chart.js is a free open source JavaScript library for data visualization, which supports 8 types of graphics: bar, line, area, pastel, bubble, radar, polar and scatter.</li>
                            </ul><br>
                            <p>In this part of the development the project skeleton is also defined, it is defined that pages will conform the final platform and the design of these, following the principles of usability and defining three clearly differentiated areas, a first minimalist that shows the data quickly and effective, then a statistical view with more accurate data and an analysis of these and finally the information formatted and prepared for the end user.</p>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" style="background-color: rgba(0,114,204,1);" id="headingTwo">
                        <h5 class="mb-0">
                            <button style="color:white;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Version 0.1.1
                            </button>
                        </h5>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                        <div class="card-body">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="card-title">Analysis and design phase completed</h5>
                                <small>30/01/2020</small>
                            </div>
                            <ul>
                            <li><p>The prototypes of the design of the page are verified and validated by the rest of the team, minor design errors are corrected so that they fit with the typology of the company.</p></li>
                            <li><p>The lines that the development will follow are defined, the system will consist of a main page in which the tickets that are currently open will be displayed, in addition we will be able to display a statistical window that will remain hidden until the user presses the expand button.</p></li><li><p> At the top of this main window we can see the three most relevant data of the project: <b> Total tickets generated </b>, <b> Time contributed </b>, <b> Total tickets closed </b>, also if we click on each of them it will redirect us to a page with more details of each section, showing a statistical view of it. The scheme of the system would be as follows:</li></p>
                            </ul>
                                <a href="index.php">
                                    <li style="margin-left:75px;">Index.php</li>
                                </a>
                                <ul>
                                    <a href="totalcalls.php">
                                        <li style="margin-left:115px;">totalcalls.php</li>
                                    </a><br>
                                    <a href="closedcalls.php">
                                        <li style="margin-left:115px;">closedcalls.php</li>
                                    </a>
                                </ul>
                                <a href="showdetailed.php">
                                    <li style="margin-left:75px;">showdetailed.php</li>
                                </a>
                            </ul><br>
                            <p><li>During the design part of the system we have worked with Adobe tools that facilitate the creation of the front-end part such as Adobe XD, from the prototypes of the windows we have been able to discuss in later meetings where to orient the page.</li></P>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header"style="background-color: rgba(0,114,204,1);" id="headingFour">
                        <h5 class="mb-0">
                            <button style="color:white;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Version 0.2
                            </button>
                        </h5>
                    </div>
                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                        <div class="card-body">
                        <div class="d-flex w-100 justify-content-between">
                                <h5 class="card-title">Web Development Started. What´s new?</h5>
                                <small>20/02/2020</small>
                            </div>
                            <ul>
                            <li><p>In this version the details of the front-end part of the system are refined, new windows are added as version.php and the rest of the windows are connected, thus providing robustness to the system.</p></li>
                            <li><p>In addition, those independent parts such as chart.js graphics are connected, adding javascript code that represents the data in the database graphically. According to different usability principles, the developer decides to hide these graphics after a panel expand collapse as it is a source of secondary information</p></li><li><p> In addition, details that facilitate the use of the page are added, adding small navigation maps to know the current position on the page, colors that make the analysis of information easier.</li></p>
                            </ul>                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header" style="background-color: rgba(0,114,204,1);"id="headingThree">
                        <h5 class="mb-0">
                            <button style="color:white;" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Version 0.2.1
                            </button>
                        </h5>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                        <div class="card-body">
                        <div class="d-flex w-100 justify-content-between">
                                <h5 class="card-title">Web Development Finished. What´s new?</h5>
                                <small>20/02/2020</small>
                            </div>
                            <ul>
                            <li><p>In this latest version of the portal, some new windows have been added, such as detailed user information. This will display a new window with all user information such as: name, contact email, belonging team and also we have created a statistical view to compare the performance of the staff by comparing the number of tickets closed per individual with the total closed by the team. We also show a table type view in which we can check the user's history.</p></li>
                            <li><p>Also in this latest version we have improved features thus providing the consistency platform, eliminating unnecessary windows that did not add any value to the page in both form and format.</p></li><li><p>Finally, we have worked on the migration of the system from the test environment to the final environment, so it will start working with the final dataset, during this last phase we will also execute different evaluation tasks with the rest of the equipment and we will review that the processes are fulfilled of usability trying to make the website as friendly as possible to the end user.</li></p>
                            </ul>                        </div>
                    </div>
                </div>
            </div>
            </div>
            <!-- DATA TABLE-->
            <!-- Siguiente -->
            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
        </div>
    </div>
    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>
</body>

</html>