<?php
require('db.php');
if (isset($_GET['pageno'])) {
    $pageno = $_GET['pageno'];
} else {
    $pageno = 1;
}
#Numero maximo de lineas mostradas por pagina
if(isset($_POST['rowsperpage'])){
     $no_of_records_per_page = $_POST['rowsperpage'];  
}else{
  $no_of_records_per_page = 10;  
}
$offset = ($pageno-1) * $no_of_records_per_page;
$filter=0;
$total_pages_sql = "SELECT COUNT(*) FROM tblsmtdata";
$result = mysqli_query($con,$total_pages_sql);
$total_rows = mysqli_fetch_array($result)[0];
$total_pages = ceil($total_rows / $no_of_records_per_page);
if(isset($_POST['FilterTeam']) && $_POST['FilterTeam']!="Team"){
    $_filterteam = $_POST['FilterTeam'];
    $filter++;
}else{
    $_filterteam = "";
}
if(isset($_POST['FilterDate']) && $_POST['FilterDate']!="Filter Date"){
  #  $_filterdate = date_sub(strtotime(date("Y-m-d")), date_interval_create_from_date_string('10 days'));
  if($_POST['FilterDate']==7){
    $_filterdate = date('Y-m-d',strtotime('-7 day',time()));
  }
  elseif($_POST['FilterDate']==30){
    $_filterdate = date('Y-m-d',strtotime('-1 month',time()));
  }
  elseif($_POST['FilterDate']==365){
    $_filterdate = date('Y-m-d',strtotime('-365 day',time()));
  }
  else{
      $_filterdate="";
  }
    $filter++;
}else{
    $_filterdate = "";
}
if($filter==0){
    $querytabla = "Select contact_id,Id,responsible_team, resolution_hours, contact_name, priority, status, caused_by from tblsmtdata where status = 'closed' order by status desc LIMIT ".$offset.",".$no_of_records_per_page.";";
}
elseif($filter==1){
    if($_filterteam != ""){
        $querytabla = "Select contact_id,Id,responsible_team,  resolution_hours, contact_name, priority, status, caused_by from tblsmtdata WHERE responsible_team like '".$_filterteam."' and status = 'closed' order by status desc LIMIT ".$offset.",".$no_of_records_per_page.";";
    }
    elseif($_filterdate != ""){
        $querytabla = "Select contact_id,Id,responsible_team,  resolution_hours, contact_name, priority, status, caused_by from tblsmtdata WHERE last_off_hold_date >='".$_filterdate."' and status='closed' order by status desc LIMIT ".$offset.",".$no_of_records_per_page.";";
    } 
}
elseif($filter==2){
    if($_filterdate == ""){
        $querytabla = "Select contact_id,Id,responsible_team,  resolution_hours, contact_name, priority, status, caused_by from tblsmtdata WHERE status like 'closed' AND responsible_team like '".$_filterteam."' order by status desc LIMIT ".$offset.",".$no_of_records_per_page.";";
    }
    elseif($_filterteam == ""){
        $querytabla = "Select contact_id,Id,responsible_team,  resolution_hours, contact_name, priority, status, caused_by from tblsmtdata WHERE status like 'closed' AND last_off_hold_date >='".$_filterdate."'order by status desc asc LIMIT ".$offset.",".$no_of_records_per_page.";";
    }
}
elseif($filter==3){
    $querytabla = "Select contact_id,Id,responsible_team,  resolution_hours, contact_name, priority, status, caused_by from tblsmtdata WHERE status like 'closed' AND last_off_hold_date >='".$_filterdate."' AND responsible_team like '".$_filterteam."' order by status desc LIMIT ".$offset.",".$no_of_records_per_page.";";
}
$result = mysqli_query($con,$querytabla) or die(mysqli_error());
echo '<div class="table-responsive table-responsive-data2">
                                <table class="table table-data2">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Resolution hours</th>
                                            <th>Contact name</th>
                                            <th>Team</th>
                                            <th>Priority</th>
                                            <th>status</th>
                                            <th>Caused by</th>
                                            <th></th>
                                        </tr>
                                    </thead>';
while($row = mysqli_fetch_assoc($result)) {
    if($row['priority']<=5){
        $color="green";
    }elseif($row['priority']>5 && $row['priority']<7){
        $color="orange";
    }else{
        $color="red";
    }
    if($row['status']=="Closed" || $row['status']=="closed" ){
        $colorstatus ="red";
    }elseif($row['status']=="Close Pend"){
        $colorstatus ="orange";
    }else{
        $colorstatus ="green";
    }
echo'
                                    <tbody>
                                        <tr class="tr-shadow">
                                            <td>'.$row['Id'].'</td>
                                            <td>
                                                <span class="block-email">'.$row['resolution_hours'].'</span>
                                            </td>
                                            <td class="desc"><a href="personal.php?val='.$row['contact_id'].'">'.$row['contact_name'].'</a></td>
                                            <td>'.$row['responsible_team'].'</td>
                                            <td style="color:'.$color.'"><b>'.$row['priority'].'</b></td>
                                            <td>
                                                <span class="status--process"style="color:'.$colorstatus.'">'.$row['status'].'</span>
                                            </td>
                                            <td>'.$row['caused_by'].'</td>
                                            <td>
                                                <div class="table-data-feature">
                                                <a href="showdetailed.php?val='.$row['Id'].'">
                                                <button class="item" data-toggle="tooltip" data-placement="top" title="More" type="submit">
                                                    <i class="zmdi zmdi-more"></i>
                                                </button></a>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    </tbody>
                                    ';
    
}
echo '</table> </div> </br>';
/*
echo '</table> </div>
<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item disabled">
      <a class="page-link" href="if($pageno <= 1){ echo \'#\'; } else { echo "?pageno=".($pageno - 1); }" tabindex="-1">Previous</a>
    </li>
    <li class="page-item">
      <a class="page-link" href="if($pageno >= $total_pages){ echo \'#\'; } else { echo "?pageno=".($pageno + 1); }">Next</a>
    </li>
  </ul>
</nav>'
    ;*/
?>