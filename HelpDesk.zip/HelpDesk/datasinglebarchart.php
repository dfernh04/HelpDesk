<?php
require('db.php');
//setting header to json
header('Content-Type: application/json');

//database
$query = "SELECT count(id) as total,responsible_team as team from tblsmtdata group by responsible_team;";
$result =  mysqli_query($con,$query) or die(mysqli_error());
$data = array();
while($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}
print json_encode($data);
?>